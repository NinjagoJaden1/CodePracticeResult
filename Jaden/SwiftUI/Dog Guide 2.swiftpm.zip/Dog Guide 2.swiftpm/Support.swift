import SwiftUI
struct Support: View {
    var showingText = false
    var body: some View {
        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Hello, world!@*/Text("Hello, world!")/*@END_MENU_TOKEN@*/
    }
}

struct Support_Previews: PreviewProvider {
    static var previews: some View {
        Support()
    }
}
